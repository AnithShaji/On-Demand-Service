﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TodoWebApi.Models;

namespace TodoWebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/UserRole")]
    public class UserRoleController : Controller
    {
        private readonly TodoContext _context;

        public UserRoleController(TodoContext context)
        {
            _context = context;
        }

        // GET: api/UserRole
        [HttpGet]
        public IEnumerable<UserRole> GetUserRole()
        {
            return _context.UserRole;
        }

        // GET: api/UserRole/5
        [HttpGet("{id}")]
        public UserRole GetUserRole(int id)

        {
            var todo = _context.UserRole.Where(m => m.UserRoleID == id).FirstOrDefault();
            return todo;
        }

        // POST: api/UserRole
        [HttpPost]
        public UserRole PostUserRole([FromBody] UserRole userRole)
        {
            int newRowID = 0;
            string sqlString = "INSERT INTO UserRole(UserRoleCode, UserRoleName) VALUES ('" + userRole.UserRoleName + "','" + userRole.UserRoleCode + "'); SELECT SCOPE_IDENTITY () As NewID";
            System.Data.SqlClient.SqlConnection sqlConnection1 =
                new System.Data.SqlClient.SqlConnection("data source=DESKTOP-MJD7GPK;initial catalog=ServiceWise;integrated security=True;MultipleActiveResultSets=True;");

            System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            cmd.CommandType = System.Data.CommandType.Text;
            cmd.CommandText = sqlString;
            //cmd.CommandText = "INSERT into UserRole VALUES ('" + userRole.UserRoleName + "','" + userRole.UserRoleCode + "')";
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();


            SqlDataReader dataReader = cmd.ExecuteReader();

            if (dataReader.HasRows)
            {
                dataReader.Read();
                newRowID = Convert.ToInt32(dataReader["NewID"]);
            }

            dataReader.Close();
            sqlConnection1.Close();
            return this.GetUserRole(newRowID);
        }
    }
}