﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TodoWebApi.Models;
using TodoWebApi.ViewModel;


namespace TodoWebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Accomodation")]
    public class AccomodationController : Controller
    {
        private readonly TodoContext _context;                                     

        public AccomodationController(TodoContext context)
        {
            _context = context;
        }
        //---LIST ALL FOOD RECIPE(GET)---
        // GET: api/Accomodation
        [HttpGet]
        public IEnumerable<Accomodation> GetAllAccomodation()
        {
            return _context.Accomodation;
        }
        // BASED ON LOCATION
        // GET: api/Accomodation/1
        [HttpGet("GetAccomodationBasedOnLocation/{LocationID}")]
        
        public List<AccomodationLocationVM> GetAccomdation(int LocationID)

        {

            List<AccomodationLocationVM> result = (from ac in _context.Accomodation.AsEnumerable()
                                               join lo in _context.Location.AsEnumerable() on ac.LocationID equals lo.LocationID where ac. LocationID == LocationID

                                                   select new AccomodationLocationVM
                                                   {
                                                   AccomodationID = ac.AccomodationID,
                                                   Location = ac.Location.LocationName,
                                                   Price = ac.Price,
                                                   AvailabilityStatus = ac.AvailabilityStatus,
                                                   FurnishStatus = ac.FurnishStatus,
                                                   SharingStatus = ac.SharingStatus,
                                                   AccomodationImg = ac.AccomodationImg,
                                                   RoomCount = ac.RoomCount,
                                                   LocationID = lo.LocationID,

                                                   

                                                   //Name = fr.CoCFirstName + " " + fr.CoCMiddleName + " " + fr.CoCLastName,
                                                   //Relationship = rg == null ? string.Empty : rg.Relationship,

                                               }).OrderBy(p => p.Price).ToList();
            return result;
        }
        

        //---ACCOMODATION BASED ON PRICE(GET)---
        // GET: api/Accomodation/(PRICE)
        [HttpGet("GetAccomodationBasedOnPrice/{Price}")]
        public List<AccomodationLocationVM> GetAccomodationBasedOnPrice(int Price)
        {
            List<AccomodationLocationVM> result = (from ac in _context.Accomodation.AsEnumerable()
                                         join lo in _context.Location.AsEnumerable() on ac.LocationID equals lo.LocationID
                                         where ac.Price == Price

                                         select new AccomodationLocationVM
                                         {
                                             AccomodationID = ac.AccomodationID,
                                             Location = ac.Location.LocationName,
                                             Price = ac.Price,
                                             AvailabilityStatus = ac.AvailabilityStatus,
                                             FurnishStatus = ac.FurnishStatus,
                                             SharingStatus = ac.SharingStatus,
                                             AccomodationImg = ac.AccomodationImg,
                                             RoomCount = ac.RoomCount,
                                             LocationID = lo.LocationID,


                                         }).OrderBy(p => p.Price).ToList();
            return result;
        }
        //---ACCOMODATION BASED ON SHARINGSTATUS(GET)---
        // GET: api/Accomodation/(SHARINGSTATUS)
        [HttpGet("GetAccomodationBasedOnSharing/{SharingStatus}")]
        public List<AccomodationLocationVM> GetAccomodationBasedOnSharing(bool SharingStatus)
        {
            List<AccomodationLocationVM> result = (from ac in _context.Accomodation.AsEnumerable()
                                                   join lo in _context.Location.AsEnumerable() on ac.LocationID equals lo.LocationID
                                                   where ac.SharingStatus == SharingStatus

                                                   select new AccomodationLocationVM
                                                   {
                                                       AccomodationID = ac.AccomodationID,
                                                       Location = ac.Location.LocationName,
                                                       Price = ac.Price,
                                                       AvailabilityStatus = ac.AvailabilityStatus,
                                                       FurnishStatus = ac.FurnishStatus,
                                                       SharingStatus = ac.SharingStatus,
                                                       AccomodationImg = ac.AccomodationImg,
                                                       RoomCount = ac.RoomCount,
                                                       LocationID = lo.LocationID,


                                                   }).OrderBy(p => p.Price).ToList();
            return result;
        }
        //---ACCOMODATION BASED ON AVAILABILTYSTATUS(GET)---
        // GET: api/Accomodation/(AVAILABILTYSTATUS)
        [HttpGet("GetAccomodationBasedOnAvailabilty/{AvailabilityStatus}")]
        public List<AccomodationLocationVM> GetAccomodationBasedOnAvailabilty(bool AvailabilityStatus)
        {
            List<AccomodationLocationVM> result = (from ac in _context.Accomodation.AsEnumerable()
                                                   join lo in _context.Location.AsEnumerable() on ac.LocationID equals lo.LocationID
                                                   where ac.AvailabilityStatus == AvailabilityStatus

                                                   select new AccomodationLocationVM
                                                   {
                                                       AccomodationID = ac.AccomodationID,
                                                       Location = ac.Location.LocationName,
                                                       Price = ac.Price,
                                                       AvailabilityStatus = ac.AvailabilityStatus,
                                                       FurnishStatus = ac.FurnishStatus,
                                                       SharingStatus = ac.SharingStatus,
                                                       AccomodationImg = ac.AccomodationImg,
                                                       RoomCount = ac.RoomCount,
                                                       LocationID = lo.LocationID,


                                                   }).OrderBy(p => p.Price).ToList();
            return result;
        }

        //---ACCOMODATION BASED ON FURNISHSTATUS(GET)---
        // GET: api/Accomodation/(FURNISHSTATUS)
        [HttpGet("GetAccomodationBasedOnFurnish/{FurnishStatus}")]
        public List<AccomodationLocationVM> GetAccomodationBasedOnFurnish(bool FurnishStatus)
        {
            List<AccomodationLocationVM> result = (from ac in _context.Accomodation.AsEnumerable()
                                                   join lo in _context.Location.AsEnumerable() on ac.LocationID equals lo.LocationID
                                                   where ac.FurnishStatus == FurnishStatus

                                                   select new AccomodationLocationVM
                                                   {
                                                       AccomodationID = ac.AccomodationID,
                                                       Location = ac.Location.LocationName,
                                                       Price = ac.Price,
                                                       AvailabilityStatus = ac.AvailabilityStatus,
                                                       FurnishStatus = ac.FurnishStatus,
                                                       SharingStatus = ac.SharingStatus,
                                                       AccomodationImg = ac.AccomodationImg,
                                                       RoomCount = ac.RoomCount,
                                                       LocationID = lo.LocationID,


                                                   }).OrderBy(p => p.Price).ToList();
            return result;
        }

        //---Accomodation Based on Price,LocationID,FurnishStatus,AvailabiltyStatus,SharingStatus(GET)---
        // GET: api/Accomodation/(Price,LocationID,FurnishStatus,AvailabiltyStatus,SharingStatus)
        [HttpPut]
        public List<AccomodationLocationVM> GetAccomp([FromBody] AccomodationsearchVm accomodationsearchVm)
        {



            List<AccomodationLocationVM> result = (from ac in _context.Accomodation.AsEnumerable()
                                                   join lo in _context.Location.AsEnumerable() on ac.LocationID equals lo.LocationID
                                                   where (ac.Price == accomodationsearchVm.Price
                                                            && ac.LocationID == accomodationsearchVm.LocationID
                                                            && ac.FurnishStatus == accomodationsearchVm.FurnishStatus
                                                            && ac.AvailabilityStatus == accomodationsearchVm.AvailabilityStatus
                                                            && ac.SharingStatus == accomodationsearchVm.SharingStatus
                                                   select new AccomodationLocationVM
                                                   {
                                                       AccomodationID = ac.AccomodationID,
                                                       Location = ac.Location.LocationName,
                                                       Price = ac.Price,
                                                       AvailabilityStatus = ac.AvailabilityStatus,
                                                       FurnishStatus = ac.FurnishStatus,
                                                       SharingStatus = ac.SharingStatus,
                                                       AccomodationImg = ac.AccomodationImg,
                                                       RoomCount = ac.RoomCount,
                                                       LocationID = lo.LocationID



                                                   }).OrderBy(p => p.Price).ToList();
                                                       
                                                       


            return result;
        }

        //POST: api/FoodRecepie
        [HttpPost]
        public FoodRecipe PostUserRole([FromBody] FoodRecipeVM foodRecipeVM)
        {
            //int newRowID = 0;
            //string sqlString = "INSERT INTO FoodRecipe(UserRoleCode, UserRoleName) VALUES ('" + userRole.UserRoleName + "','" + userRole.UserRoleCode + "'); SELECT SCOPE_IDENTITY () As NewID";
            //System.Data.SqlClient.SqlConnection sqlConnection1 =
            //    new System.Data.SqlClient.SqlConnection("data source=DESKTOP-MJD7GPK;initial catalog=ServiceWise;integrated security=True;MultipleActiveResultSets=True;");

            //System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
            //cmd.CommandType = System.Data.CommandType.Text;
            //cmd.CommandText = sqlString;
            ////cmd.CommandText = "INSERT into UserRole VALUES ('" + userRole.UserRoleName + "','" + userRole.UserRoleCode + "')";
            //cmd.Connection = sqlConnection1;

            //sqlConnection1.Open();


            //SqlDataReader dataReader = cmd.ExecuteReader();

            //if (dataReader.HasRows)
            //{
            //    dataReader.Read();
            //    newRowID = Convert.ToInt32(dataReader["NewID"]);
            //}

            //dataReader.Close();
            //sqlConnection1.Close();
            //return this.GetUserRole(newRowID);
            Region regionInstance = new Region();
            int regionID = 1;

            FoodRecipe foodRecipeInstance = new FoodRecipe();

            if (foodRecipeVM.FoodRecipeID == 0)
            {
                if (!string.IsNullOrEmpty(foodRecipeVM.Region))
                {
                    regionInstance = new Region();
                    regionInstance.RegionName = foodRecipeVM.Region;
                    regionInstance.RegionCode = foodRecipeVM.Region.Substring(0, 3);
                    this._context.Region.Add(regionInstance);
                    this._context.SaveChanges();
                    regionID = regionInstance.RegionID;
                }

                foodRecipeInstance = new FoodRecipe();
                foodRecipeInstance.FoodName = foodRecipeVM.FoodName;
                foodRecipeInstance.Description = foodRecipeVM.Description;
                foodRecipeInstance.Recepie = foodRecipeVM.Recepie;
                foodRecipeInstance.FoodType = foodRecipeVM.FoodType;
                foodRecipeInstance.EatingTime = foodRecipeVM.EatingTime;
                foodRecipeInstance.RegionID = regionID;
                foodRecipeInstance.UserID = foodRecipeVM.UserID;
                foodRecipeInstance.Chef = foodRecipeVM.Chef;
                foodRecipeInstance.TotalCookTime = foodRecipeVM.TotalCookTime;
                foodRecipeInstance.DifficultyLevel = foodRecipeVM.DifficultyLevel;
                foodRecipeInstance.CreatedDate = foodRecipeVM.CreatedDate;
                this._context.FoodRecipe.Add(foodRecipeInstance);
                this._context.SaveChanges();
            }
            else
            {
                foodRecipeInstance = this._context.FoodRecipe.Where(p => p.FoodRecipeID == foodRecipeVM.FoodRecipeID).FirstOrDefault();
                if (foodRecipeInstance != null)
                {
                    foodRecipeInstance.FoodName = foodRecipeVM.FoodName;
                    foodRecipeInstance.Description = foodRecipeVM.Description;
                    foodRecipeInstance.Recepie = foodRecipeVM.Recepie;
                    foodRecipeInstance.FoodType = foodRecipeVM.FoodType;
                    foodRecipeInstance.EatingTime = foodRecipeVM.EatingTime;
                    foodRecipeInstance.RegionID = foodRecipeVM.RegionID;
                    foodRecipeInstance.UserID = foodRecipeVM.UserID;
                    foodRecipeInstance.Chef = foodRecipeVM.Chef;
                    foodRecipeInstance.TotalCookTime = foodRecipeVM.TotalCookTime;
                    foodRecipeInstance.DifficultyLevel = foodRecipeVM.DifficultyLevel;
                    this._context.FoodRecipe.Attach(foodRecipeInstance);
                    this._context.Entry(foodRecipeInstance).State = EntityState.Modified;
                    this._context.SaveChanges();
                }

            }
            return foodRecipeInstance;

        }
    }
}