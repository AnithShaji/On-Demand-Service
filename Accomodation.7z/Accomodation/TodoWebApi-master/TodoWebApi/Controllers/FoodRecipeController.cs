﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TodoWebApi.Models;
using TodoWebApi.ViewModel;

namespace TodoWebApi.Controllers
{
    [Produces("application/json")]
    [Route("api/FoodRecipe")]
    public class FoodRecipeController : Controller
    {
        private readonly TodoContext _context;

        public FoodRecipeController(TodoContext context)
        {
            _context = context;
        }

        // GET: api/FoodRecepie
        [HttpGet]
        public IEnumerable<FoodRecipe> GetAllFoodRecepie()
        {
            var x = _context.FoodRecipe;
            return _context.FoodRecipe;
        }

        // GET: api/FoodRecepie/5
        [HttpGet("{regionID}")]
        public List<FoodRecipeRegionVM> GetRecepie(int regionID)

        {

            List<FoodRecipeRegionVM> result = (from fr in _context.FoodRecipe.AsEnumerable()
                                               join rg in _context.Region.AsEnumerable() on fr.RegionID equals rg.RegionID

                                               select new FoodRecipeRegionVM
                                               {
                                                   FoodRecipeID = fr.FoodRecipeID,
                                                   FoodName = fr.FoodName,
                                                   Recepie = fr.Recepie,
                                                   FoodType = fr.FoodType,
                                                   EatingTime = fr.EatingTime,
                                                   Chef = fr.Chef,
                                                   TotalCookTime = fr.TotalCookTime,
                                                   Region = rg.RegionName,
                                                   RegionID = rg.RegionID,
                                                   DifficultyLevel = fr.DifficultyLevel,
                                                   Description = fr.Description

                                                   //Name = fr.CoCFirstName + " " + fr.CoCMiddleName + " " + fr.CoCLastName,
                                                   //Relationship = rg == null ? string.Empty : rg.Relationship,

                                               }).OrderByDescending(p => p.TotalCookTime).ToList();
            return result;
        }

        // POST: api/UserRole
        //[HttpPost]
        //public UserRole PostUserRole([FromBody] UserRole userRole)
        //{
        //    int newRowID = 0;
        //    string sqlString = "INSERT INTO UserRole(UserRoleCode, UserRoleName) VALUES ('" + userRole.UserRoleName + "','" + userRole.UserRoleCode + "'); SELECT SCOPE_IDENTITY () As NewID";
        //    System.Data.SqlClient.SqlConnection sqlConnection1 =
        //        new System.Data.SqlClient.SqlConnection("data source=DESKTOP-MJD7GPK;initial catalog=ServiceWise;integrated security=True;MultipleActiveResultSets=True;");

        //    System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand();
        //    cmd.CommandType = System.Data.CommandType.Text;
        //    cmd.CommandText = sqlString;
        //    //cmd.CommandText = "INSERT into UserRole VALUES ('" + userRole.UserRoleName + "','" + userRole.UserRoleCode + "')";
        //    cmd.Connection = sqlConnection1;

        //    sqlConnection1.Open();


        //    SqlDataReader dataReader = cmd.ExecuteReader();

        //    if (dataReader.HasRows)
        //    {
        //        dataReader.Read();
        //        newRowID = Convert.ToInt32(dataReader["NewID"]);
        //    }

        //    dataReader.Close();
        //    sqlConnection1.Close();
        //    return this.GetUserRole(newRowID);
        //}
    }
}