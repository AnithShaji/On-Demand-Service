﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace TodoWebApi.Models
{
    public class TodoContext : DbContext
    {
        public TodoContext (DbContextOptions<TodoContext> options)
            : base(options)
        {
        }

        //public DbSet<TodoWebApi.Models.Todo> Todo { get; set; }
        public DbSet<TodoWebApi.Models.UserRole> UserRole { get; set; }
        public DbSet<TodoWebApi.Models.Users> Users { get; set; }
        public DbSet<TodoWebApi.Models.ServiceType> ServiceType { get; set; }
        public DbSet<TodoWebApi.Models.OnDemandService> OnDemandService { get; set; }
        public DbSet<TodoWebApi.Models.Region> Region { get; set; }
        public DbSet<TodoWebApi.Models.FoodRecipe> FoodRecipe { get; set; }
        public DbSet<TodoWebApi.Models.Accomodation> Accomodation { get; set; }
        public DbSet<TodoWebApi.Models.Location> Location { get; set; }

    }
}
