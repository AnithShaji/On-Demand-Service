﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TodoWebApi.Models
{
    public class FoodRecipe
    {
        /// <summary>
        /// Gets or sets the primary key
        /// </summary>
        [Key]
        public int FoodRecipeID { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public string FoodName { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string Recepie { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string FoodType { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string EatingTime { get; set; }

        /// <summary>
        /// Gets or sets the user type ID
        /// </summary>
        public int RegionID { get; set; }

        /// <summary>
        /// Gets or sets the user type
        /// </summary>
        public virtual Region Region { get; set; }

        /// <summary>
        /// Gets or sets the user type ID
        /// </summary>
        [ForeignKey("Users")]
        public int UserID { get; set; }

        /// <summary>
        /// Gets or sets the user type
        /// </summary>
        public virtual Users Users { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string Chef { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public int? TotalCookTime { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string DifficultyLevel { get; set; }


    }
}
