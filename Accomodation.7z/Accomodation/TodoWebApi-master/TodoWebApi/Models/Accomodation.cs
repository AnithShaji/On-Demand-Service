﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;


namespace TodoWebApi.Models
{
    public class Accomodation
    {
        /// <summary>
        /// Gets or sets the primary key
        /// </summary>
        [Key]
        public int AccomodationID { get; set; }

      
        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public int Price { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public bool AvailabilityStatus { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public bool FurnishStatus { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public bool SharingStatus { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string AccomodationImg{ get; set; }

        /// <summary>
        /// Gets or sets the user type ID
        /// </summary>
        public int RoomCount { get; set; }
        /// Gets or sets the user type ID
        /// </summary>
        public int LocationID { get; set; }

        /// <summary>
        /// Gets or sets the user type
        /// </summary>
        public virtual Location Location{ get; set; }

        /// <summary>
        /// Gets or sets the user User Role ID
        /// </summary>
        [ForeignKey("Users")]
        public int Users { get; set; }

    }
}
