﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TodoWebApi.Models
{
    public class Location
    {
        /// <summary>
        /// Gets or sets the primary key
        /// </summary>
        [Key]
        public int LocationID { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public string LocationCode { get; set; }
    }
}
