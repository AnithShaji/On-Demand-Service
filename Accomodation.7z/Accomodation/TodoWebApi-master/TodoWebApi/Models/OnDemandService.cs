﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace TodoWebApi.Models
{
    public class OnDemandService
    {
        /// <summary>
        /// Gets or sets the primary key
        /// </summary>
        [Key]
        public int OnDemandServiceID { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public int? Price { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public bool AvailabilityStatus { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public bool PaymentStatus { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string Notes { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string Feedback { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string ServiceImg { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public int? Rating { get; set; }

        /// <summary>
        /// Gets or sets the user type ID
        /// </summary>
        [ForeignKey("Users")]
        public int UserID { get; set; }

        /// <summary>
        /// Gets or sets the user type
        /// </summary>
        public virtual Users Users { get; set; }

        /// <summary>
        /// Gets or sets the user type ID
        /// </summary>
        [ForeignKey("ServiceType")]
        public int ServiceTypeID { get; set; }

        /// <summary>
        /// Gets or sets the user type
        /// </summary>
        public virtual ServiceType ServiceType { get; set; }

    }
}
