﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TodoWebApi.ViewModel
{
    public class FoodRecipeRegionVM
    {
        /// <summary>
        /// Gets or sets the primary key
        /// </summary>
        public int FoodRecipeID { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public string FoodName { get; set; }

        /// <summary>
        /// Gets or sets the user type name
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string Recepie { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string FoodType { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string EatingTime { get; set; }

        /// <summary>
        /// Gets or sets the user type ID
        /// </summary>
        public int RegionID { get; set; }

        /// <summary>
        /// Gets or sets the user type
        /// </summary>
        public string  Region { get; set; }

        /// <summary>
        /// Gets or sets the user type ID
        /// </summary>

        public int UserID { get; set; }


        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string Chef { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public int? TotalCookTime { get; set; }

        /// <summary>
        /// Gets or sets the user type Code
        /// </summary>
        public string DifficultyLevel { get; set; }

    }
}
